package org.cap.model;

import java.util.Date;

public class UserPojo {
	
	private Integer userID;
	private String name;
	private Date doj;
	private String city;
	private String gender;
	
	public UserPojo() {
		
	}

	public UserPojo(Integer userID, String name, Date doj, String city, String gender) {
		super();
		this.userID = userID;
		this.name = name;
		this.doj = doj;
		this.city = city;
		this.gender = gender;
	}

	public Integer getUserID() {
		return userID;
	}

	public void setUserID(Integer userID) {
		this.userID = userID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "UserPojo [userID=" + userID + ", name=" + name + ", doj=" + doj + ", city=" + city + ", gender="
				+ gender + "]";
	}	
	
	
}
