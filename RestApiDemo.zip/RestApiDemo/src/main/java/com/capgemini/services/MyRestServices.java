package com.capgemini.services;

import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.capgemini.dao.IproductDao;
import com.capgemini.dao.ProductDaoImpl;
import com.capgemini.model.Product;

@Path("/api")
public class MyRestServices {
	
	private IproductDao iproductDao=new ProductDaoImpl();
	
	@GET
	@Path("/products")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getProducts(){
		return iproductDao.getAllProducts();
	}
	
	@POST
	@Path("/addproducts")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> addProducts(@FormParam("productId") int productId,@FormParam("productName") String productName){
		return iproductDao.addnewProduct(productId, productName);
	}
	
	@DELETE
	@Path("/deleteproducts/{productId}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> deleteProducts(@PathParam("productId") int productId){
		return iproductDao.removeProduct(productId);
	}
	
	@GET
	@Path("/findproducts/{productId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Product findProducts(@PathParam("productId") int productId){
		return iproductDao.getProduct(productId);
	}
	
	@GET
	@Path("/hello")
	public String sayHello() {
		return "Hello World! from RestAPI";
	}

	@GET
	@Path("/greet/{userName}")
	@Produces(MediaType.TEXT_HTML)
	public String greetUser(@PathParam("userName") String myUser) {
		
		return "<h1 style='color:red;'>Hello! " + myUser +"</h1>";
	}
	
	
	@GET
	@Path("/loaddata")
	@Produces(MediaType.TEXT_XML)
	public String getXml() {
		return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
				+ "<employee>"
				+ "<firstname>tom</firstname>"
				+ "<lastname>jack</lastname>"
				+ "<age>23</age>"
				+ "</employee>";
	}
	
	@GET
	@Path("/loadjson")
	@Produces(MediaType.APPLICATION_JSON)
	public String getJSON() {
		return "{"
				+ "\"firstname\":\"Arindam\","
				+ "\"lastname\":\"Bhowmick\","
				+ "\"age\":22"
				+ "}";
	}

}
