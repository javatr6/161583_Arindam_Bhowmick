package com.capgemini.truckbooking.client;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.BookingException;
import com.capgemini.truckbooking.service.CustomerValidator;
import com.capgemini.truckbooking.service.ITruckService;
import com.capgemini.truckbooking.service.TruckService;

public class BookingClient {
	private static Logger myUILogger=Logger.getLogger(BookingClient.class);
	private static Scanner scanner=new Scanner(System.in);
	private static TruckBean truckDetails=new TruckBean();
	private static ITruckService truckService=new TruckService();
	private static CustomerValidator validator=new CustomerValidator();
	private static Methods method=new Methods();
	
	public static void main(String[] args) {
		PropertyConfigurator.configure("resource/log4j.properties");
		
		int option;
		while(true){
			
			System.out.println();
			System.out.println("Truck Booking System");
			System.out.println("------------");
			System.out.println("1.Book Truck");
			System.out.println("2.Delete");
			System.out.println("3.Exit");
			System.out.println();
			System.out.println("Enter option: ");
			
			option=scanner.nextInt();
			
			try {
				switch(option) {
				
				case 1:
					truckService.bookTrucks(method.bookingDetails());										
					break;
				case 2:
					System.out.println("Enter truck id to delete");
					int truckId=scanner.nextInt();
					truckService.deleteTruck(truckId);
					break;
				case 3:
					System.exit(0);
				}
			}catch(Exception e) {
				myUILogger.error(e);
				scanner.nextLine();
				System.err.println("Truck problem");
			}
			
		}
		

	}
}
