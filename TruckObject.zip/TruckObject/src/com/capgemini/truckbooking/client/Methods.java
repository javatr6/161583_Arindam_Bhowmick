package com.capgemini.truckbooking.client;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.BookingException;
import com.capgemini.truckbooking.service.CustomerValidator;
import com.capgemini.truckbooking.service.ITruckService;
import com.capgemini.truckbooking.service.TruckService;


public class Methods {
	private static Logger myUILogger=Logger.getLogger(Methods.class);
	private static Scanner scanner=new Scanner(System.in);
	private static TruckBean truckDetails=new TruckBean();
	private static ITruckService truckService=new TruckService();
	private static CustomerValidator validator=new CustomerValidator();
	
	
	public BookingBean bookingDetails() throws BookingException, SQLException {

		BookingBean obj = new BookingBean();

		System.out.println("Enter customer id: ");
		String custId=scanner.nextLine();
		//**************************************************************
		if(validator.isValidCustomerId(custId)) 
		{
			obj.setCustId(custId);
			List<TruckBean> truckDetails=truckService.retrieveTruckDetails();
			Iterator<TruckBean> iterator=truckDetails.iterator();
			while(iterator.hasNext()) 
			{
				System.out.println(iterator.next());
			}
			//**************************************************************

			System.out.println("");
			System.out.println("---------------------------");

			System.out.println("Please enter truckId to book truck: ");
			int truckId=scanner.nextInt();			
			if(truckService.isValidTruckId(truckId)) 
			{
				obj.setTruckId(truckId);
				System.out.println("Enter number of truck to be booked(only numeric value): ");
				int noOfTrucks=scanner.nextInt();
				if(truckService.isValidAvailableNos(truckId,noOfTrucks)==1) 
				{
					obj.setNoOfTrucks(noOfTrucks);
					System.out.println("Enter Customer Mobile:");
					long custMobile=scanner.nextLong();
					if(validator.isValidPhoneNumber(custMobile)) 
					{
						obj.setCustMobile(custMobile);
						System.out.println("Enter date of transportation(YYYY-MM-DD): ");
						scanner.nextLine();
						CharSequence date=scanner.nextLine();		
						/*String date=scanner.next();
						DateFormat dateFormat= new SimpleDateFormat("yyyy-mm-dd");
						java.util.Date udate= dateFormat.parse(date);
						java.sql.Date sqldate=new java.sql.Date(udate.getTime());*/ 
						
						
						if(validator.isValidDate(date)) 
						{
							LocalDate dateOfTransport=LocalDate.parse(date);
							obj.setDateOfTransport(dateOfTransport);
						}
						else
						{
							System.out.println("Enter valid Date!!!!!!!!");
						}
					}
					else 
					{
						System.out.println("Enter valid Phone Number!!!!!!!!");
					}
				}
				else 
				{
					System.out.println("Sorry No More Trucks available!!!!!!!");
					return null;
				}														
			}
			else
			{
				System.out.println("Enter valid Truck ID!!!!!!!!");
				
			}
		}
		else 
		{
			System.out.println("Enter valid customer ID!!!!!!!!!");
			
		}										


		return obj;

	}
}
