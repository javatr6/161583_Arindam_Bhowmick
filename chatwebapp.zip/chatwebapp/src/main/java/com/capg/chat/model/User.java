package com.capg.chat.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



@Entity
public class User {
	@Id
	@GeneratedValue
	private Integer userId;
	private String userName;
	
	@OneToMany(mappedBy="user",targetEntity=Chat.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY) 
	@JsonIgnoreProperties("user")
	List<Chat> chats=new ArrayList<>();

	
	public User() {
		super();
	}

	public User(Integer userId, String userName, List<Chat> chats) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.chats = chats;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public List<Chat> getChats() {
		return chats;
	}

	public void setChats(List<Chat> chats) {
		this.chats = chats;
	}
	
	
	
}
