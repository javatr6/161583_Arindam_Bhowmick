package com.capg.chat.service;

import java.util.List;

import com.capg.chat.model.Message;

public interface IMsgService {

	List<Message> saveMessage(Message message);

	List<Message> getAllMessages();

}
