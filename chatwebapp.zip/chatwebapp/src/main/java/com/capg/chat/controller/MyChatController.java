package com.capg.chat.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.chat.model.Chat;
import com.capg.chat.model.Message;
import com.capg.chat.service.IChatService;
import com.capg.chat.service.IMsgService;
import com.capg.chat.service.IUserSerice;
@RestController
@CrossOrigin("*")
@RequestMapping("/api")

public class MyChatController {
	@Autowired
	private IChatService chatService;
	@Autowired
	private IMsgService msgService;
	@Autowired
	private IUserSerice userService;
	
	@PostMapping("/chat")
	private ResponseEntity<List<Chat>> saveChat(@RequestBody Chat chat){
		List<Chat> chats=chatService.saveChat(chat);
		if(chats.isEmpty()) {
			return new ResponseEntity("Sorry",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Chat>>(chats,HttpStatus.OK);
	}
	@GetMapping("/chat")
	private ResponseEntity<List<Chat>> getAllChats(){
		List<Chat> chats=chatService.getAllChats();
		if(chats.isEmpty()) {
			return new ResponseEntity("Sorry",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Chat>>(chats,HttpStatus.OK);
	}
	@PostMapping("/messages")
	private ResponseEntity<List<Message>> saveMessage(@RequestBody Message message){
		List<Message> messages=msgService.saveMessage(message);
		if(messages.isEmpty()) 
		 return new ResponseEntity("Sorryy",HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Message>>(messages,HttpStatus.OK);
	}
	@GetMapping("/messages")
	private ResponseEntity<List<Message>> getAllMessages(){
		List<Message> messages=msgService.getAllMessages();
		if(messages.isEmpty())
			return new ResponseEntity("Sorry",HttpStatus.NOT_FOUND);
	return new ResponseEntity<List<Message>>(messages,HttpStatus.OK);
	}
	@GetMapping("/chat/chats")
	private ResponseEntity<List<Chat>> getChats(@RequestBody Chat chat){
		System.out.println("hsdfk");
		List<Chat> chats=chatService.getChatMessage(chat);
		if(chats.isEmpty()) {
			for(Chat m:chats) {
				System.out.println(m.getMessages());
			}
			return new ResponseEntity("Sorry",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Chat>>(chats,HttpStatus.OK);
	}
	
}
