package com.capgemini;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;


public class SITester {
	public static void main(String[] args) throws MalformedURLException {
		URL url=new URL("http://localhost:7704/ws/calculator?wsdl");
		QName qname=new QName("http://service.cap.com/","CalculatorImplService");

		Service service=Service.create(url,qname);
		CalculateSI calculatorSI=service.getPort(CalculateSI.class);
		
		System.out.println(calculatorSI.calculateSi(200, 10,1));
}
	
}
