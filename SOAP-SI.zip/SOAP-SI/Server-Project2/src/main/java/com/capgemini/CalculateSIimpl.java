package com.capgemini;

import javax.jws.WebService;

@WebService(endpointInterface="com.capgemini.CalculateSI")
public class CalculateSIimpl implements CalculateSI {
	
	@Override
	public double calculateSi(int p, int r, int t) {
		
		return p*p*t*(.01);
	}

}
