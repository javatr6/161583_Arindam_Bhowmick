package com.capgemini;

import javax.xml.ws.Endpoint;



public class SIPublisher {

	public static void main(String[] args) {
		Endpoint.publish("http://localhost:7701/ws/CalculateSI", new CalculateSIimpl());
	}

}
