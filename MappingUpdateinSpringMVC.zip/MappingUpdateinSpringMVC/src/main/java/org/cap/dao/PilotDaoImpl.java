package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.cap.model.Aircraft;
import org.cap.model.City;
import org.cap.model.Pilot;
import org.cap.model.pilot_aircraft;
import org.springframework.stereotype.Repository;

@Repository("pilotDao")
@Transactional
public class PilotDaoImpl implements IPilotDao{
	@PersistenceContext
	private EntityManager em;

	@Override
	public void savePilot(Pilot pilot) {
		em.persist(pilot);
		
		
	}
	@Override
	public List<Pilot> getPilotDetails() {
		List<Pilot> pilotList=em.createQuery("from Pilot").getResultList();
		return pilotList;
	}
	@Override
	public void deletePilot(Integer pilotId) {
		Pilot pilot=em.find(Pilot.class, pilotId);
		if(pilot!=null) {
			em.remove(pilot);
	}

}
	@Override
	public Pilot updatePilot(Pilot p) {
		System.out.println(p);
		    em.merge(p);
			return p;
		
		
	
	}
	@Override
	public Pilot getPiotById(Integer pilotId) {
		Pilot pilot=em.find(Pilot.class, pilotId);
		return pilot;
	}
	@Override
	public List<City> getAllCities() {
		List<City> cityList=em.createQuery("from City").getResultList();
		return cityList;
	}
	@Override
	public boolean addPilotCertification(Integer pilotId,String aircraftId) {
		pilot_aircraft pa=new pilot_aircraft(pilotId,aircraftId);
		em.persist(pa);
		return true;
	}
	@Override
	public List<Aircraft> getAircraft() {
		List<Aircraft> aircraftList=em.createQuery("from Aircraft").getResultList();
		return aircraftList;
	}

		
	}
