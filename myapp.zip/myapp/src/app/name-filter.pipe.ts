import { PipeTransform, Pipe } from '@angular/core';
import { Customer } from './customer';
import { filter } from 'rxjs/operators';

@Pipe({
    name: 'nameFilter'
})
export class NameFilterPipe implements PipeTransform {
    transform(value: Customer[], args: string[]): Customer[] {
        let filter: string = args[0] ? args[0].toLocaleLowerCase() : null;
        return filter ? value.filter((customer: Customer) =>
         customer.firstName.toLocaleLowerCase().indexOf(filter) != -1) : value;
    }

}

