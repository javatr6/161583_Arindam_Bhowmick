import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chatdemo',
  templateUrl: './chatdemo.component.html',
  styleUrls: ['./chatdemo.component.css']
})
export class ChatdemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
