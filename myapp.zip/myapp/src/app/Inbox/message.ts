export interface IMessage{
    text: string;
    chat_Id:number;
}