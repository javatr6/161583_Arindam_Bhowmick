import { Component, OnInit } from '@angular/core';
import { InboxService } from './inbox.service';
import { IMessage } from './message';
import { error } from '@angular/compiler/src/util';

@Component({
  selector: 'pm-Inbox',
  templateUrl: './Inbox.component.html',
  styleUrls: ['./Inbox.component.css']
})
export class Inbox implements OnInit {

  public pageTitle: string='inboxhome';
  inbox:IMessage[]=[];
  errorMessage:string;

  constructor(private _inboxService:InboxService) { }

  ngOnInit() {

    this._inboxService.getMsg(1).subscribe(inbox=> {
      this.inbox=inbox;
    },
    error=>this.errorMessage=<any>error
    
    );
  }

  getMsg(chat_Id:number){
    this._inboxService.getMsg(chat_Id);
  }

}
