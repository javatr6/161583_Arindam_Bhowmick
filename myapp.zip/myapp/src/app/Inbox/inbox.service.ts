import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { IMessage } from './message';
const httpOptions ={
  headers :new HttpHeaders({'Content-Type':'application/json'})
  };

@Injectable({
  providedIn: 'root'
})
export class InboxService {

  private _friendUrl='http://localhost:8084/api';
  _Url:string='http://localhost:8084/api';
  
  private message:string='chat';
  constructor(private _http:HttpClient) { }

  getMsg(chat_Id:number){
    this._friendUrl=this._Url+'/'+'chat'+'/'+chat_Id;
    return this._http.get<IMessage[]>(this._friendUrl)
  }
}
