import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {CustserviceService} from './custservice.service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustomerComponent } from './customer/customer.component';
import { HttpClientModule }    from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import {NameFilterPipe} from './name-filter.pipe';
import { CustomerFormComponent } from './customer-form/customer-form.component';
import { ChatCap } from './capbook/capbook.component';
import { ChatdemoComponent } from './chatdemo/chatdemo.component';
import { Inbox} from './Inbox/Inbox.component';
import { ConversationComponent } from './conversation/conversation.component'

@NgModule({
  declarations: [
    AppComponent,
    CustomerComponent,
    NameFilterPipe,
    CustomerFormComponent,
    ChatdemoComponent,
    Inbox,
    ConversationComponent
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
   
  ],
  providers: [CustserviceService],
  bootstrap: [AppComponent]

})
export class AppModule { }
