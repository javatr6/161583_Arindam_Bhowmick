import { Component, OnInit } from '@angular/core';
import {CustserviceService} from '../custservice.service';
import {Customer} from '../customer';
@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  customers: Customer[];
  fname:string='tom';
  constructor(private custService:CustserviceService) { }

  ngOnInit() {
    this.getCustomers()
  }

  getCustomers():void{
    this.custService.getCustomers()
      .subscribe(customers=> this.customers=customers )
  }

}
