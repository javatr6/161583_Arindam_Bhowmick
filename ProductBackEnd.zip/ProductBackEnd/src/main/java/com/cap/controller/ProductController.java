package com.cap.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.dao.IProductDao;
import com.cap.model.Productpojo;
import com.cap.service.IProductService;
import com.cap.util.ProductUtil;

@RestController
@RequestMapping("/api")
public class ProductController {

	@Autowired
	private IProductService productService;

	@Autowired
	private IProductDao productDao;

	@PostMapping("/products")
	public ResponseEntity<List<Productpojo>> saveProduct(@RequestBody Productpojo product){
		List<Productpojo> products=productService.saveProduct(product);
		if(products.isEmpty()) {
			return new ResponseEntity("Sorry",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Productpojo>>(products, HttpStatus.OK);		
	}
	@GetMapping("/products")
	public ResponseEntity<List<Productpojo>> getProduct(){
		List<Productpojo> products=productService.getProductDetails();
		if(products.isEmpty()) {
			return new ResponseEntity("Sorry No Products Found..",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Productpojo>>(products, HttpStatus.OK);

	}


	@DeleteMapping("/products/{productId}")
	public ResponseEntity<List<Productpojo>> deleteProduct(
			@PathVariable("productId")Integer productId){
		List<Productpojo> products= productService.deleteProduct(productId);
		if(products.isEmpty() || products==null) {
			return new ResponseEntity("Sorry! ProductsId not available!", 
					HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Productpojo>>(products, HttpStatus.OK);
	}


	@PutMapping("/products")
	public ResponseEntity<List<Productpojo>> updateProduct(
			@RequestBody Productpojo product){
		List<Productpojo> products= productService.updateProduct(product);
		if(products.isEmpty())
		{
			return new ResponseEntity("Sorry! Products not available!", 
					HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Productpojo>>(products, HttpStatus.OK);
	}

	@GetMapping("/products/{input}")
	public ResponseEntity<List<Productpojo>> findProduct(@PathVariable("input") String input){
		List<Productpojo> products=productDao.findProduct(input);
		if(products.isEmpty()) {
			return new ResponseEntity("Sorry No Products Found..",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Productpojo>>(products, HttpStatus.OK);

	}

}
