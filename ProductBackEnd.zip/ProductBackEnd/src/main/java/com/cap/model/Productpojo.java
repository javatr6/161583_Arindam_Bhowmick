package com.cap.model;

import java.util.Arrays;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Productpojo {

	@Id
	@GeneratedValue
	private Integer productId;
	private String productName;
	private String description;
	private Date expiryDate;
	private Integer quantity;
	private Double price;
	private String category;
	private byte[] Image;
	public Productpojo() {
		super();
	}
	public Productpojo(Integer productId, String productName, String description, Date expiryDate, Integer quantity,
			Double price, String category, byte[] image) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.description = description;
		this.expiryDate = expiryDate;
		this.quantity = quantity;
		this.price = price;
		this.category = category;
		Image = image;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public byte[] getImage() {
		return Image;
	}
	public void setImage(byte[] image) {
		Image = image;
	}
	@Override
	public String toString() {
		return "Productpojo [productId=" + productId + ", productName=" + productName + ", description=" + description
				+ ", expiryDate=" + expiryDate + ", quantity=" + quantity + ", price=" + price + ", category="
				+ category + ", Image=" + Arrays.toString(Image) + "]";
	}
	
}
