package com.cap.service;

import java.util.List;

import com.cap.model.Productpojo;

public interface IProductService {

	public List<Productpojo> saveProduct(Productpojo product);
	public List<Productpojo> deleteProduct(Integer productId);
	public List<Productpojo> updateProduct(Productpojo product);
	public List<Productpojo> getProductDetails();
	
}
