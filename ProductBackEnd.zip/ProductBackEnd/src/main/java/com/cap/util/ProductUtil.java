package com.cap.util;

import java.util.ArrayList;
import java.util.List;

public class ProductUtil {

	public static List<String> getAllCategories(){
		List<String> categories=new ArrayList<>();
		categories.add("Mobile");
		categories.add("Computer Accessories");
		categories.add("Clothing");
		categories.add("Groceries");
		return categories;
	}
}


