package com.capgemini.service;

import com.capgemini.pojo.Routetable;

public interface IRouteAddService {
	public abstract Routetable addRoute(Routetable newroute);
}
