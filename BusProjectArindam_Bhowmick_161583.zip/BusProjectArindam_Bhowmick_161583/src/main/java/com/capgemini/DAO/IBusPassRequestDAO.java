package com.capgemini.DAO;

import com.capgemini.pojo.PassRequestFormPOJO;

public interface IBusPassRequestDAO {
	public abstract PassRequestFormPOJO createRequest(PassRequestFormPOJO passRequestPOJO) ;
}
