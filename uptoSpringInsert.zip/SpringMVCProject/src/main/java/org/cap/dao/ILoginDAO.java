package org.cap.dao;

import java.util.List;

import org.cap.model.UserPojo;

public interface ILoginDAO {

	public boolean validLogin(String userName, String userPwd);
	public void saveUser(UserPojo user);
	public List<UserPojo> getUserDetails();
}
