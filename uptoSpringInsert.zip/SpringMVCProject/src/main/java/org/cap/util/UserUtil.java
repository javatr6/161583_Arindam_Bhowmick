package org.cap.util;

import java.util.ArrayList;
import java.util.List;

public class UserUtil {

	public static List<String> getAllCities(){
		List<String> cities=new ArrayList<>();
		cities.add("Chennai");
		cities.add("Tanuku");
		cities.add("Hyderabad");
		cities.add("Banswada");
		return cities;
	}
	
	public static List<String> getQualifications() {
		
		List<String> qualificationsList = new ArrayList<>();
		qualificationsList.add("Engineer");
		qualificationsList.add("Bsc");
		qualificationsList.add("ME");
		qualificationsList.add("MTech");
		return qualificationsList;
	}
}
