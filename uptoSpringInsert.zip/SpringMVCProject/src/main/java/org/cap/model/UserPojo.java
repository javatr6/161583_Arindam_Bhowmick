package org.cap.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class UserPojo {
	
	@Id
	@GeneratedValue
	private Integer userId;
	private String username;
	private String city;
	private String gender;
	private String qualification;
	private Date doj;
	
	public UserPojo() {
		
	}

	public UserPojo(Integer userId, String username, String city, String gender, String qualification, Date doj) {
		super();
		this.userId = userId;
		this.username = username;
		this.city = city;
		this.gender = gender;
		this.qualification = qualification;
		this.doj = doj;
	}
	
	

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	@Override
	public String toString() {
		return "UserPojo [userId=" + userId + ", username=" + username + ", city=" + city + ", gender=" + gender
				+ ", qualification=" + qualification + ", doj=" + doj + "]";
	}

}
