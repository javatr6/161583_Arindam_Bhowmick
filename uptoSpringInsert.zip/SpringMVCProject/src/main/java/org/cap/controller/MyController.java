package org.cap.controller;

import javax.validation.Valid;

import org.cap.model.UserPojo;
import org.cap.service.ILoginService;
import org.cap.util.UserUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MyController {

	@Autowired
	private ILoginService loginService;

	@RequestMapping(value="/validateLogin",method=RequestMethod.POST)
	public String validateLogin(@RequestParam("userName") String userName,@RequestParam("userPwd") String userPwd,ModelMap map) {
		
		if(loginService.validLogin(userName,userPwd)) {
			map.addAttribute("user",new UserPojo());
			map.addAttribute("qualificationsList",UserUtil.getQualifications());
			map.addAttribute("cities",UserUtil.getAllCities());
			map.addAttribute("userList",loginService.getUserDetails());
			return "redirect:/UserDetails";
		}
		else
			
			return "redirect:/";		
	}
	
	
	@RequestMapping(value="/UserDetails")
	
	public String UserDetailsPage(ModelMap map) {
		map.addAttribute("user",new UserPojo());
		map.addAttribute("qualificationsList",UserUtil.getQualifications());
		map.addAttribute("userList",loginService.getUserDetails());
		map.addAttribute("cities",UserUtil.getAllCities());
		return "UserDetails";
	}
	

	@RequestMapping(value="/saveUser",method=RequestMethod.POST)
	
	public String saveUser(@Valid @ModelAttribute("user")UserPojo user,BindingResult bindingResult) {
		if(bindingResult.hasErrors()) {
			return "success";
		}
		else {
			loginService.saveUser(user);
		}
		return "redirect:/UserDetails";
		
	}
}
