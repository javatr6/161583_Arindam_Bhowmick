package hotelbooking;


import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	private WebDriver driver;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\aribhowm\\Desktop\\selinium\\chromedriver.exe");
		driver=new ChromeDriver();
	}

@Given("^open Hotel Booking page$")
public void open_Hotel_Booking_page() throws Throwable {
	driver.get("http://localhost:8082/HotelManagementSystem/pages/hotelbooking.html");
	String head = driver.findElement(By.xpath("/html/body/div/h2")).getText();
	assertEquals("Hotel Booking Form",head);
}

@Given("^Personel and payment details$")
public void personel_and_payment_details() throws Throwable {
	driver.findElement(By.name("txtFN")).sendKeys("Arindam");
	driver.findElement(By.name("txtLN")).sendKeys("Bhowmick");
	driver.findElement(By.name("Email")).sendKeys("Arindam@gmail.com");
	driver.findElement(By.name("Phone")).sendKeys("8005840431");
	driver.findElement(By.xpath("/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("Kolkata");
	WebElement mySelectElement = driver.findElement(By.name("city"));
	Select dropdown= new Select(mySelectElement);
	dropdown.selectByVisibleText("Kolkata");
	WebElement mySelectstate = driver.findElement(By.name("state"));
	Select dropdownState= new Select(mySelectstate);
	dropdownState.selectByVisibleText("Bengal");
	WebElement persons = driver.findElement(By.name("persons"));
	Select dropdownpersons= new Select(persons);
	dropdownpersons.selectByVisibleText("2");
	
	driver.findElement(By.xpath("//*[@id=\"txtCardholderName\"]")).sendKeys("Arindam");
	driver.findElement(By.name("debit")).sendKeys("965175008956723");
	driver.findElement(By.name("cvv")).sendKeys("451");
	driver.findElement(By.name("month")).sendKeys("02");
	driver.findElement(By.name("year")).sendKeys("2019");
	
}

@When("^Personel And payment details are not empty$")
public void personel_And_payment_details_are_not_empty() throws Throwable {
	WebElement confirm=driver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));
	confirm.click();
}

@Then("^navigate to success page$")
public void navigate_to_success_page() throws Throwable {
	driver.navigate().to("http://localhost:8082/HotelManagementSystem/pages/success.html");
}

@Given("^Personel and payment details are null$")
public void personel_and_payment_details_are_null() throws Throwable {
	driver.findElement(By.name("txtFN")).sendKeys("");
   
}

@When("^Personel And payment details are empty$")
public void personel_And_payment_details_are_empty() throws Throwable {
	WebElement confirm=driver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));
	confirm.click();
}

@Then("^show alert messages$")
public void show_alert_messages() throws Throwable {
	String msg = driver.switchTo().alert().getText();
	assertEquals("Please fill the First Name",msg);
}
}
