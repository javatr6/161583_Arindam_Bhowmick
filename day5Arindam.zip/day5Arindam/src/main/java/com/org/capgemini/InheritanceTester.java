package com.org.capgemini;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class InheritanceTester {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		
		Project project=new Project(1001,"arindam");
		
		Module module=new Module();
		module.setProjectId(12);
		module.setProjectName("Transaction Management");
		module.setModuleName("Validation");
		
		Task task=new Task();
		task.setProjectId(121);
		task.setProjectName("Task");
		task.setModuleName("abc");
		task.setTaskName("task1");
		
		entityManager.persist(project);
		entityManager.persist(module);
		entityManager.persist(task);
		
		transaction.commit();
		 entityManager.close();
		
	}

}
