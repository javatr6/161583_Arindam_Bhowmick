export interface IMessage{
    text: string;
}