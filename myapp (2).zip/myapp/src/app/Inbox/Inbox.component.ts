import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-Inbox',
  templateUrl: './Inbox.component.html',
  styleUrls: ['./Inbox.component.css']
})
export class Inbox implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
