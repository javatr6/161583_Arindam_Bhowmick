import { Component } from "@angular/core";

@Component({
    selector:'chat-root',
    templateUrl:'./capbook.component.html',
    styleUrls:['./capbook.component.css']
})
export class ChatCap{

}