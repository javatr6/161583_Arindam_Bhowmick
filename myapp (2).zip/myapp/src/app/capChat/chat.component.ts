import { Component } from "@angular/core";

@Component({
    selector:'chat1-root',
    templateUrl:'./chat.component.html',
    styleUrls:['./chat.component.css']
})
export class Chat{

}