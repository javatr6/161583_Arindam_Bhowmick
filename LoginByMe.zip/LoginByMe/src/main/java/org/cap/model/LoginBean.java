package org.cap.model;

public class LoginBean {
	private String username;
	private String userpassword;
	
	public LoginBean() {
		
	}

	public LoginBean(String username, String userpassword) {
		super();
		this.username = username;
		this.userpassword = userpassword;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	
	
	public String getUserpassword() {
		return userpassword;
	}

	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}	
}
