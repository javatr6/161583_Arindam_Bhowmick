package org.cap.model;

public class RouteBean {
	private int routeid;
	private String routepath;
	private String routename;
	private int totalseat;
	private int occupiedseat;
	private String busno;
	private String driverno;
	private int km;
	
	public RouteBean() {
		
	}

	public RouteBean(int routeid, String routepath, String routename, int totalseat, int occupiedseat, String busno,
			String driverno, int km) {
		super();
		this.routeid = routeid;
		this.routepath = routepath;
		this.routename = routename;
		this.totalseat = totalseat;
		this.occupiedseat = occupiedseat;
		this.busno = busno;
		this.driverno = driverno;
		this.km = km;
	}

	public int getRouteid() {
		return routeid;
	}

	public void setRouteid(int routeid) {
		this.routeid = routeid;
	}

	public String getRoutepath() {
		return routepath;
	}

	public void setRoutepath(String routepath) {
		this.routepath = routepath;
	}

	public String getRoutename() {
		return routename;
	}

	public void setRoutename(String routename) {
		this.routename = routename;
	}

	public int getTotalseat() {
		return totalseat;
	}

	public void setTotalseat(int totalseat) {
		this.totalseat = totalseat;
	}

	public int getOccupiedseat() {
		return occupiedseat;
	}

	public void setOccupiedseat(int occupiedseat) {
		this.occupiedseat = occupiedseat;
	}

	public String getBusno() {
		return busno;
	}

	public void setBusno(String busno) {
		this.busno = busno;
	}

	public String getDriverno() {
		return driverno;
	}

	public void setDriverno(String driverno) {
		this.driverno = driverno;
	}

	public int getKm() {
		return km;
	}

	public void setKm(int km) {
		this.km = km;
	}
	
	
	
}
