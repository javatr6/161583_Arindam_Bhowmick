package org.cap.service;

import org.cap.dao.ILoginDao;
import org.cap.dao.LoginDaoImpl;
import org.cap.model.BusRequest;
import org.cap.model.LoginBean;

public class LoginserviceImpl implements Iloginservice {

	private ILoginDao loginDao;
	
	
	
	public LoginserviceImpl() {
		this.loginDao=new LoginDaoImpl();
	}



	@Override
	public Boolean isValidLogin(LoginBean loginBean) {
		if(loginDao.isValidLogin(loginBean)) {
			return true;
		}
		return false;
	}



	@Override
	public BusRequest createRequest(BusRequest passRequestBean) {
		// TODO Auto-generated method stub
		return null;
	}	
}
