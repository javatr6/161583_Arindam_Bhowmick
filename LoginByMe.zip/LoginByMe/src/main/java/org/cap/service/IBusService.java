package org.cap.service;

import java.util.List;

import org.cap.model.RouteBean;

public interface IBusService {
	public List<RouteBean> getAllRoutes();
}
