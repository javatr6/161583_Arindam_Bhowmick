package org.cap.service;

import java.util.List;

import org.cap.dao.BusServiceDaoImpl;
import org.cap.dao.IBusServiceDao;
import org.cap.model.RouteBean;

public class BusServiceImpl implements IBusService{
	
	private IBusServiceDao busServiceDao;
	
	public BusServiceImpl() {
		this.busServiceDao=new BusServiceDaoImpl();
	}

	@Override
	public List<RouteBean> getAllRoutes() {
		
		return busServiceDao.getAllRoutes();
	}

}
