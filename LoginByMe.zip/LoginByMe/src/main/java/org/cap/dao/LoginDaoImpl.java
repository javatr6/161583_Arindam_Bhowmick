package org.cap.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.cap.model.LoginBean;

public class LoginDaoImpl implements ILoginDao {

	@Override
	public Boolean isValidLogin(LoginBean loginBean) {
		
		String sql="select * from adminlogin where username=? and userpassword=?";
		try(
				PreparedStatement pst=getMysqlDBConnection().prepareStatement(sql);
			){
			pst.setString(1, loginBean.getUsername());
			pst.setString(2, loginBean.getUserpassword());
			ResultSet resultSet = pst.executeQuery();
			if(resultSet.next()) {
				return true;
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	private Connection getMysqlDBConnection() {
		Connection connection=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/capdb","root","India@123");
			
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return connection;
				
	}

}
