package org.cap.dao;

import java.util.List;

import org.cap.model.RouteBean;

public interface IBusServiceDao {
	
	public List<RouteBean> getAllRoutes();

}
