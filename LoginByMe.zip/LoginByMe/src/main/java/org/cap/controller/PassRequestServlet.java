package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalTime;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.model.BusRequest;
import org.cap.service.Iloginservice;
import org.cap.service.LoginserviceImpl;


@WebServlet("/PassRequestServlet")
public class PassRequestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		Iloginservice loginService=new LoginserviceImpl();
		
		String employeeId=request.getParameter("employeeID");
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String email=request.getParameter("emailId");
		String gender=request.getParameter("gender");
		String address=request.getParameter("address");
		String doj=request.getParameter("dateOfJoining");
		String location=request.getParameter("location");
		String pickuploc=request.getParameter("pickUpLocation");
		String pickuptime=request.getParameter("pickUpTime");
		String designation=request.getParameter("designation");
		
		
		BusRequest requestBean=new BusRequest();
		requestBean.setEmployeeID(employeeId);
		requestBean.setFirstName(firstName);
		requestBean.setLastName(lastName);
		requestBean.setEmailId(email);
		requestBean.setGender(gender);
		requestBean.setAddress(address);
		requestBean.setLocation(location);
		requestBean.setPickUpLocation(pickuploc);
		requestBean.setDesignation(designation);
		
		String[] datepart=doj.split("-");
		/*for(String str:datepart)
		System.out.println(str);*/
		LocalDate dateOfJoin= LocalDate.of(Integer.parseInt(datepart[0]), 
				Integer.parseInt(datepart[1]), Integer.parseInt(datepart[2]));
		requestBean.setDateOfjoining(dateOfJoin);
		
		
		String[] timepart=pickuptime.split(":");
		LocalTime picktime=LocalTime.of(Integer.parseInt(timepart[0]), Integer.parseInt(timepart[1]));
		requestBean.setPickUpTime(picktime);
	
		//System.out.println(requestBean);
		
		BusRequest passRequestBean= loginService.createRequest(requestBean);
		PrintWriter out=response.getWriter();
		
		
		if(passRequestBean!=null) {
			request.getRequestDispatcher("pages/BusPassRequestForm.html").include(request, response);
			out.println("Insertion Success..........");
		}
		else {
			request.getRequestDispatcher("pages/BusPassRequestForm.html").include(request, response);
			out.println("Insertion Failed..........");
			System.out.println("Insertion Failed..........");
		}
	}

}
