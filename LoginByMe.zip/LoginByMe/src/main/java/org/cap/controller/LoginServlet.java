package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.model.LoginBean;
import org.cap.service.Iloginservice;
import org.cap.service.LoginserviceImpl;
//Arindam

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		String userName=request.getParameter("userName");
		String userPwd=request.getParameter("userPwd");
		
		LoginBean loginBean=new LoginBean(userName,userPwd);
		Iloginservice loginService=new LoginserviceImpl();
		
		if(loginService.isValidLogin(loginBean)) {
			//response.sendRedirect("pages/success.html");
			request.getRequestDispatcher("pages/Admin.html").include(request, response);
			out.println(userName+" is Authorized User!");
		}else {
			//response.sendRedirect("index.html");
			request.getRequestDispatcher("index.html").include(request, response);
			out.println("Sorry!" + userName+" is not Authorized User!");
		}		
	}

}
