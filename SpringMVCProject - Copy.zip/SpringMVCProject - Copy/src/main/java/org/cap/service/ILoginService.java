package org.cap.service;

import org.cap.model.UserPojo;

public interface ILoginService {
	public boolean validLogin(String userName, String userPwd);

	public void saveUser(UserPojo user);
}
