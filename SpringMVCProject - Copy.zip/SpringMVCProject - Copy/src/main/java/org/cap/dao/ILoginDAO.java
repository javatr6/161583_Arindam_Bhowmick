package org.cap.dao;

import org.cap.model.UserPojo;

public interface ILoginDAO {

	public boolean validLogin(String userName, String userPwd);

	public void saveUser(UserPojo user);
}
