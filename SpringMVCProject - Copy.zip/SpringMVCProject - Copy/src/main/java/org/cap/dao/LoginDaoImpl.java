package org.cap.dao;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Login;
import org.cap.model.UserPojo;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("LoginDao")
@Transactional
public class LoginDaoImpl implements ILoginDAO {

	private Login login;
	
	@PersistenceContext
	private EntityManager em;
	

	@Override
	public boolean validLogin(String userName, String userPwd) {
		login=em.find(Login.class, userName);
		if(login.getUserName().equals(userName) && login.getPassword().equals(userPwd))
		{
			return true;
		}
		return false;
	}


	@Override
	public void saveUser(UserPojo user) {
		
		em.persist(user);
	}

}
