package com.capgemini.LMS.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.LMS.bean.BooksInventoryBean;
import com.capgemini.LMS.bean.BooksRegistrationBean;
import com.capgemini.LMS.bean.UsersBean;
import com.capgemini.LMS.exception.LibraryException;
import com.capgemini.LMS.util.DBConnection;

public class RegistrationDaoImpl implements IRegistrationDao{
	private static Logger daoLogger=Logger.getLogger(RegistrationDaoImpl.class);

	@Override
	public List<BooksRegistrationBean> getRegistration(UsersBean usersBean , BooksInventoryBean booksInventory) throws LibraryException {
		List<BooksRegistrationBean> booksRegistration =new ArrayList<>();
		
		
		
		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();)
		{
			BooksInventoryBean book = new BooksInventoryBean();
			UsersBean userid = new UsersBean();
			PreparedStatement preparedStatement1=connection.prepareStatement(QueryMapper.CHECK_USER_ID);
			PreparedStatement preparedStatement2=connection.prepareStatement(QueryMapper.DISPLAY_USERS);
			PreparedStatement preparedStatement3=connection.prepareStatement(QueryMapper.DISPLAY_BOOK_REGISTRATION);
			preparedStatement1.setString(1, usersBean.getUserId());
			ResultSet resultSet1= preparedStatement1.executeQuery();
			ResultSet resultSet2= preparedStatement2.executeQuery();
			ResultSet resultSet3= preparedStatement3.executeQuery();
			
			
			while(resultSet3.next())
			{
				
				book.setBookId(resultSet3.getString(1));
				
			}
			
			while(resultSet2.next())
			{
				userid.setUserId(resultSet2.getString(1));
			}
			
			while(resultSet1.next())
			{
				BooksRegistrationBean reg =new BooksRegistrationBean();
				reg.setRegistrationId(resultSet1.getString(1));
				reg.setBookId(book);
				reg.setUserId(userid);
				reg.setRegistrationDate(resultSet1.getDate(4).toLocalDate());
				booksRegistration.add(reg);	
			
			}
		}	catch (SQLException e) {
			daoLogger.error(e);
			throw new LibraryException("Technical error refer logs");

		}
		return booksRegistration;
	}

	@Override
	public void doRegistration(BooksInventoryBean booksInventory, UsersBean usersBean, BooksRegistrationBean booksRegistration) throws LibraryException {
		
		
		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();)
		{
			PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.INSERT_BOOK_REGISTRATION);
			
			preparedStatement.setString(1, booksRegistration.getRegistrationId());
			preparedStatement.setString(2, booksRegistration.getBookId().getBookId());
			preparedStatement.setString(3, booksRegistration.getUserId().getUserId());
			preparedStatement.setDate(4, java.sql.Date.valueOf(booksRegistration.getRegistrationDate()));
			
			int row=preparedStatement.executeUpdate();
			
			if(row>0)
				System.out.println("Your book has been registered and forwarded to librarian!");			
		} catch (SQLException e) {
			daoLogger.error(e);
			throw new LibraryException("Technical error refer logs");

		}
		
	}
}
