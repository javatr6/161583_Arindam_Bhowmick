package com.capgemini.LMS.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.LMS.bean.UsersBean;
import com.capgemini.LMS.exception.LibraryException;
import com.capgemini.LMS.util.DBConnection;




public class LoginDaoImpl implements ILoginDao{
	private static Logger daoLogger=Logger.getLogger(LoginDaoImpl.class);

	@Override
	public List<UsersBean> getAllUsers() throws LibraryException {

		int Count=0;
		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
				)
		{
			ResultSet resultSet= statement.executeQuery(QueryMapper.DISPLAY_USERS);
			List<UsersBean> usersList = new ArrayList<>();
			while(resultSet.next())
			{
				Count++;
				UsersBean usersBean = new UsersBean();
				usersBean.setUserId(resultSet.getString(1));
				usersBean.setUserName(resultSet.getString(2));
				usersBean.setPassword(resultSet.getString(3));
				usersBean.setEmailId(resultSet.getString(4));
				usersBean.setLibrarian(resultSet.getBoolean(5));
				usersList.add(usersBean);
			}

			if(Count!=0) {
				return usersList;
			}
			else {
				return null;
			}
		} catch (SQLException e) {
			daoLogger.error(e);
			throw new LibraryException("Technical error refer logs");
		}


	}
	public Boolean validStudent(String userId,String userName, String password, int c) throws LibraryException {

		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
				PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.DISPLAY_USERS);
				)
		{		
			ResultSet resultSet =preparedStatement.executeQuery();
			while(resultSet.next()) {
				if(resultSet.getString(1).compareTo(userId)==0 && resultSet.getString(2).compareTo(userName)==0 && resultSet.getString(3).compareTo(password)==0 && resultSet.getInt(5)==c)
				{					 
					return true;
				}					
			}

		} catch (SQLException e) {
			daoLogger.error(e);
			throw new LibraryException("Technical error refer logs");

		}
		return false;
	}
	public Boolean validLibrarian(String userNameLib, String passwordLib, int c) throws LibraryException {
		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
				)
		{
			PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.DISPLAY_USERS);
			ResultSet resultSet =preparedStatement.executeQuery();
			while(resultSet.next()) {
				if(resultSet.getString(2).equals(userNameLib) && resultSet.getString(3).equals(passwordLib)&& resultSet.getInt(5)==c)
				{
					return true;
				}
			}

		} catch (SQLException e) {
			daoLogger.error(e);
			throw new LibraryException("Technical error refer logs");

		}
		return false;

	}
	@Override
	public void addStudent(UsersBean student) throws LibraryException {
		
		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();)
		{
			PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.INSERT_Student);
			preparedStatement.setString(1, student.getUserId());
			preparedStatement.setString(2, student.getUserName());
			preparedStatement.setString(3, student.getPassword());
			preparedStatement.setString(4, student.getEmailId());
			preparedStatement.setBoolean(5, student.getLibrarian());
			int row=preparedStatement.executeUpdate();

			if(row>0)
				System.out.println("You are registered student");

		} catch (SQLException e) {
			daoLogger.error(e);
			throw new LibraryException("Technical error refer logs");

		}			
		
	}

}
