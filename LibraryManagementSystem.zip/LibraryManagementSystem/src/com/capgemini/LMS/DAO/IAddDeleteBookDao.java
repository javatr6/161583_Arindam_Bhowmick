package com.capgemini.LMS.DAO;

import java.util.List;

import com.capgemini.LMS.bean.BooksInventoryBean;
import com.capgemini.LMS.exception.LibraryException;

public interface IAddDeleteBookDao {
	
	public void addBook(BooksInventoryBean booksInventory)throws LibraryException;
	public List<BooksInventoryBean> getAllBooks()throws LibraryException;
	public void deleteBook(String bookId)throws LibraryException;

}
