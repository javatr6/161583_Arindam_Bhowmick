package com.capgemini.LMS.client;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.capgemini.LMS.bean.BooksInventoryBean;
import com.capgemini.LMS.bean.BooksRegistrationBean;
import com.capgemini.LMS.bean.BooksTransactionBean;
import com.capgemini.LMS.bean.UsersBean;

public class UserInteraction {

	Scanner scanner = new Scanner(System.in);
	BooksInventoryBean booksInventoryBean = new BooksInventoryBean();
	BooksRegistrationBean booksRegistrationBean = new BooksRegistrationBean();
	BooksTransactionBean booksTransactionBean = new BooksTransactionBean();
	UsersBean usersBean = new UsersBean();


	public void printBooks(List<BooksInventoryBean> booksList)
	{
		System.out.println("BookID \t\tBookName \tAuthor1 \tAuthor2 \tPublisher \tYearofPublisher");
		System.out.println("------------------------------------------------------------------------------------------");

		for(BooksInventoryBean book:booksList)
		{
			System.out.println(book.getBookId()+"\t\t"+book.getBookName()+"\t\t"+book.getAuthor1()+"\t\t"+book.getAuthor2()+"\t\t"+book.getPublisher()+"\t\t"+book.getYearOfPub());
		}
	}
	public void printRegistrationRequest(List<BooksRegistrationBean> registers)
	{
		System.out.println("UserID  \tRegistrationDate ");
		System.out.println("-----------------------------------------------------------------");

		for(BooksRegistrationBean register:registers)
		{
			System.out.println(register.getRegistrationId()+"\t\t"+register.getRegistrationDate());
		}
	}


	public void printTransactions(List<BooksTransactionBean> transactions)
	{
		System.out.println("TransactionID \t IssueDate \t ReturnDate \t Fine");
		System.out.println("-----------------------------------------------------------------");

		for(BooksTransactionBean transaction:transactions)
		{
			System.out.println(transaction.getTransactionId()+"\t"+transaction.getIssueDate());
		}
	}

	public BooksInventoryBean findallbooks(List<BooksInventoryBean> books)
	{


		System.out.println("Enter your Book_Id");
		String Book_Id;
		Book_Id=scanner.next();

		for(BooksInventoryBean book : books)
		{

			if(Book_Id.equals(book.getBookId()))
			{
				return book;
			}

		}

		return null;
	}


	public BooksInventoryBean getBook(String book_id, List<BooksInventoryBean> books)
	{
		for(BooksInventoryBean book:books)
		{
			if(book.getBookId().equals(book_id));
			return book;
		}
		System.out.println("Enter valid Book ID!");
		return null;
	}

	public UsersBean getUser(String userId, List<UsersBean> users)
	{
		for(UsersBean user:users)
		{
			if(user.getUserId().equals(userId));
			{
				return user;
			}
		}
		System.out.println("Enter valid User ID!");
		return null;
	}

	public BooksRegistrationBean getRegister(String user_id, List<BooksRegistrationBean> registers)
	{
		for(BooksRegistrationBean register:registers)
		{
			if(register.getRegistrationId().equals("user_id"));
			return register;
		}
		System.out.println("Enter valid Registration ID!");
		return null;
	}


	public BooksTransactionBean getTransaction(String transact_id, List<BooksTransactionBean> transactions)
	{
		for(BooksTransactionBean transaction:transactions)
		{
			if(transaction.getRegistrationId().equals("transact_id"));
			return transaction;
		}
		System.out.println("Enter valid Transaction ID!");
		return null;
	}

	public BooksRegistrationBean register(BooksInventoryBean bookId , UsersBean userId)
	{	
		System.out.println("You can register by filling details");
		System.out.println("Enter your registration_Id[User Id]");
		String reg_id = scanner.next();
		booksRegistrationBean.setRegistrationId(reg_id);
		booksRegistrationBean.setBookId(bookId);
		booksRegistrationBean.setUserId(userId);
		LocalDate reg_date = LocalDate.now();
		System.out.println("Your registration date"+reg_date);
		booksRegistrationBean.setRegistrationDate(reg_date);
		return booksRegistrationBean;
	}



	public BooksInventoryBean getDetailsofBook()
	{
		System.out.println("Enter Book Id");
		String book_id = scanner.nextLine();
		booksInventoryBean.setBookId(book_id);
		scanner.nextLine();
		
		System.out.println("Enter Book Name");
		String book_name = scanner.nextLine();
		booksInventoryBean.setBookName(book_name);
		
		System.out.println("Enter Book Author 1");
		String author1 = scanner.nextLine();
		booksInventoryBean.setAuthor1(author1);
		
		System.out.println("Enter Book Author 2");
		String author2 = scanner.nextLine();
		booksInventoryBean.setAuthor2(author2);
		
		System.out.println("Enter Book Publisher");
		String publisher = scanner.nextLine();
		booksInventoryBean.setPublisher(publisher);
		
		System.out.println("Enter Book Year of Publishing");
		String yearofpub = scanner.nextLine();
		booksInventoryBean.setYearOfPub(yearofpub);

		return booksInventoryBean;

	}

	public BooksTransactionBean transaction(BooksRegistrationBean bookreg)
	{	
		System.out.println("You can do transaction by entering transaction_id");
		System.out.println("Enter your Transaction_Id");
		String trans_id = scanner.next();
		booksTransactionBean.setTransactionId(trans_id);
		booksTransactionBean.setRegistrationId(bookreg);
		LocalDate issueDate = LocalDate.now();
		System.out.println("Your issue date is"+issueDate);
		booksTransactionBean.setIssueDate(issueDate);		
		return booksTransactionBean;
	}
	
	public UsersBean getDetailsofStudent() {
		
		System.out.println("Enter User Id");
		String userId = scanner.nextLine();
		usersBean.setUserId(userId);
		
		System.out.println("Enter User Name");
		String userName = scanner.nextLine();
		usersBean.setUserName(userName);
		
		System.out.println("Enter User Password");
		String userPassword = scanner.nextLine();
		usersBean.setPassword(userPassword);
		
		System.out.println("Enter email");
		String email = scanner.nextLine();
		usersBean.setEmailId(email);
		
		System.out.println("Enter Librarian or student");
		Boolean type = scanner.nextBoolean();
		usersBean.setLibrarian(type);		
		
		return usersBean;
	}
}



