package com.capgemini.LMS.service;

import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.LMS.DAO.ILoginDao;
import com.capgemini.LMS.DAO.LoginDaoImpl;
import com.capgemini.LMS.bean.UsersBean;
import com.capgemini.LMS.exception.LibraryException;

public class LoginServiceImpl implements ILoginService{

	ILoginDao loginDao = new LoginDaoImpl();

	public final static Logger logger=Logger.getLogger(LoginServiceImpl.class);


	public void runMe(String parameter)
	{
		if(logger.isDebugEnabled())
		{
			logger.debug("This is debug: "+parameter);
		}

		if(logger.isInfoEnabled())
		{
			logger.info("This is info: "+parameter);
		}

		logger.warn("This is warn: "+parameter);
		logger.error("This is error: "+parameter);
		logger.fatal("This is fatal: "+parameter);
	}

	@Override
	public Boolean validStudent(String userId,String userName, String password, int c) throws LibraryException {

		if(Validations.isvaliduser(userName))
		{
			Boolean bool = loginDao.validStudent(userId,userName, password, c);
			return bool;
		}else
		{
			logger.error("customer is invalid");	
			try {
				throw new LibraryException ("details not in proper format..so account cant be created");
			}catch (LibraryException e) {
				e.printStackTrace();
			}
		}
		return false;
	}
	@Override
	public Boolean validLibrarian(String userNameLib, String passwordLib, int c) throws LibraryException {

		if(Validations.isvaliduser(userNameLib))
		{
			Boolean booleanResult = loginDao.validLibrarian(userNameLib, passwordLib, c);
			return booleanResult;
		}else
		{
			logger.error("User is invalid");	
			try {
				throw new LibraryException("Details not in proper format..so  cant login");
			} catch (LibraryException e) {
				e.printStackTrace();
			}
		}
		return false;
	}
	@Override
	public List<UsersBean> getAllUsers() throws LibraryException {
		return loginDao.getAllUsers();
	}

	@Override
	public void addStudent(UsersBean student) throws LibraryException {
		loginDao.addStudent(student);		
	}
}
