package com.capgemini.LMS.service;

import java.util.List;

import com.capgemini.LMS.DAO.ITransactionDao;
import com.capgemini.LMS.DAO.TransactionDaoImpl;
import com.capgemini.LMS.bean.BooksRegistrationBean;
import com.capgemini.LMS.bean.BooksTransactionBean;
import com.capgemini.LMS.exception.LibraryException;

public class TransactionServiceImpl implements ITransactionService {

	
	ITransactionDao transactiondao = new TransactionDaoImpl(); 
	@Override
	public void doTransaction(BooksTransactionBean booksTransaction, BooksRegistrationBean booksRegistration) throws LibraryException {
		transactiondao.doTransaction(booksTransaction,booksRegistration);			
	}

	/*@Override
	public List<BooksTransactionBean> getAllTransaction(BooksRegistrationBean booksRegistration) throws LibraryException {
		return transactiondao.getAllTransaction(booksRegistration);
	}*/
}
