package com.capg.chat.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capg.chat.model.User;

@Repository("userDao")
public interface IUserDao extends JpaRepository<User, Integer> {

}
