package com.capg.chat.service;

public interface IUserSerice {

}
