package com.capg.chat.service;

import org.springframework.stereotype.Service;

@Service("userService")
public class UserServiceImpl implements IUserSerice {

}
