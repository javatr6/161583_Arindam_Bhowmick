package com.capg.chat.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.chat.dao.IMsgDao;
import com.capg.chat.model.Message;

@Service("msgService")
public class MsgServiceImpl implements IMsgService {
	@Autowired
	private IMsgDao msgDao;

	@Override
	public List<Message> saveMessage(Message message) {
		msgDao.save(message);
		return msgDao.findAll();
	}

	@Override
	public List<Message> getAllMessages() {
		
		return msgDao.findAll();
	}
}
