package com.capg.chat.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.chat.dao.IChatDao;
import com.capg.chat.model.Chat;
import com.capg.chat.model.Message;

@Service("chatService")
public class ChatServiceImpl implements IChatService{

	@Autowired
	private IChatDao chatDao;

	@Override
	public List<Chat> saveChat(Chat chat) {
	
		Chat chat1=chatDao.VerifyingChat(chat.getUser().getUserId(),chat.getUser_Receiver_Id());
		//System.out.println(chat1);
		if(chat1==null) {
			System.out.println("assdff");
			chatDao.save(chat);
			
		}
		else {
			System.out.println("dfsf");
			List<Message> msg=chat1.getMessages();
			msg.addAll(chat.getMessages());
			chat1.setMessages(msg);
			chatDao.save(chat1);
		}
		
		return chatDao.findAll();
	}

	@Override
	public List<Chat> getAllChats() {
		return chatDao.findAll();
	}

	@Override
	public List<Chat> getChatMessage(Chat chat) {
		Chat chat1=chatDao.VerifyingChat(chat.getUser().getUserId(),chat.getUser_Receiver_Id());
		if(chat1!=null)
			return chatDao.findByChatId(chat1.getChat_Id());
		return null;
	}

	@Override
	public List<Chat> getChatMessage(Integer user_id, Integer rec_id) {
		Chat chat1=chatDao.VerifyingChat(user_id,rec_id);
		if(chat1!=null)
		{
			System.out.println(chat1.getChat_Id());
			return chatDao.findByChatId(chat1.getChat_Id());
		}
		return null;
	}
}
