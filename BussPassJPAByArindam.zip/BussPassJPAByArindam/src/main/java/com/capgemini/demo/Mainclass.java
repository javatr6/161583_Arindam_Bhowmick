package com.capgemini.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Mainclass {

	public static void main(String[] args) {
		EntityManagerFactory emf = 
        		Persistence.createEntityManagerFactory("jpademo");
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction= em.getTransaction();
        
        transaction.begin();
     Login login=new Login("Asis","dha123");
     Login login1=new Login("Antara","Aant");
     Login login2=new Login("Avija","Avijaaaaaavija");
     Login login3=new Login("Arindam","Arindam18feb");
     Login login4=new Login("Srikhar","cr");
     Login login5=new Login("Anondo","Anand");
      
     Busroute busroute1=new Busroute();
     busroute1.setRoutePath("Barasat Airport Baruipur");
     busroute1.setRouteName("Barasat-Baruipur");
     busroute1.setOccupied(25);
     busroute1.setTotalSeats(46);
     busroute1.setDiverName("Sadhan");
     busroute1.setBusNo("WB-4567");
     busroute1.setTotalKm(40);
     
     Busroute busroute2=new Busroute();
     busroute2.setRoutePath("Barasat Airport Howrah");
     busroute2.setRouteName("Barasat-Howrah");
     busroute2.setOccupied(21);
     busroute2.setTotalSeats(46);
     busroute2.setDiverName("Gopal");
     busroute2.setBusNo("WB-2967");
     busroute2.setTotalKm(23);
       
        em.persist(login);
        em.persist(login1);
        em.persist(login2);
        em.persist(login3);
        em.persist(login4);
        em.persist(login5);
        em.persist(busroute1);
        em.persist(busroute2);
        
        transaction.commit();
        em.close();

	}

}
