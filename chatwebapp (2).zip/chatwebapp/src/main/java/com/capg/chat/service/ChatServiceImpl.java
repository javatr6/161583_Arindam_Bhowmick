package com.capg.chat.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.chat.dao.IChatDao;
import com.capg.chat.model.Chat;
import com.capg.chat.model.Message;

@Service("chatService")
public class ChatServiceImpl implements IChatService{

	@Autowired
	private IChatDao chatDao;

	@Override
	public List<Chat> saveChat(Chat chat) {
	
		Chat chat1=chatDao.VerifyingChat(chat.getUser_Sender_Id(),chat.getUser_Receiver_Id());
		//System.out.println(chat1);
		if(chat1==null) {
			System.out.println("assdff");
			chatDao.save(chat);
			
		}
		else {
			System.out.println("dfsf");
			List<Message> msg=chat1.getMessages();
			msg.addAll(chat.getMessages());
			chat1.setMessages(msg);
			chatDao.save(chat1);
		}
		
		return chatDao.findAll();
	}

	@Override
	public List<Chat> getAllChats() {
		return chatDao.findAll();
	}

	@Override
	public List<Chat> getAllChats(Integer chat_id) {
		
		return chatDao.findChatById(chat_id);
	}
}
