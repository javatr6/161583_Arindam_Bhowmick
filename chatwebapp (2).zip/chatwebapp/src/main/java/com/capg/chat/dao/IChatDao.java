package com.capg.chat.dao;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capg.chat.model.Chat;

@Repository("chatDao")
public interface IChatDao extends JpaRepository<Chat, Long>{

	@Query("from Chat where user_Sender_Id=:user_Sender_Id and user_Receiver_Id=:user_Receiver_Id")
	public Chat VerifyingChat(@Param("user_Sender_Id") Integer user_Sender_Id,@Param("user_Receiver_Id") Integer user_Receiver_Id);
	@Query("from Chat where chat_id=:chat_Id")
	public List<Chat> findChatById(@Param("chat_Id") Integer chat_id);
}
