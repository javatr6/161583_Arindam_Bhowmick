package com.capg.chat.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capg.chat.model.Message;

@Repository("msgDao")
@Transactional
public interface IMsgDao extends JpaRepository<Message, Integer>{


	/*@Query("from Message m where m.message_id in(select cm.message_id from chat_message cm where cm.chat_id=:input)")
	public List<Message> getAllConversation(@Param("input")Long input);
	@Query("SELECT p FROM Chat p join p.message chat c WHERE c.chat_id =:input")
	public List<Message> getAllConversation(@Param("input")Long input);*/
	
}
